package com.capgemini.exception;

public class DuplicateMobileNumberException extends Exception {

}
