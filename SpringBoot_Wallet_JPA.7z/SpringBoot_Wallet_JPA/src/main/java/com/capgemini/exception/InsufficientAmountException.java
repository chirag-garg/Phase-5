package com.capgemini.exception;

public class InsufficientAmountException extends Exception {

}
